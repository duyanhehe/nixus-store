# Nguồn của agent `agency-xr-interface-architect`

Một agent lẻ của gói `nixus.agency-agents`, lấy từ [msitarzewski/agency-agents/spatial-computing/xr-interface-architect.md](https://github.com/msitarzewski/agency-agents/blob/main/spatial-computing/xr-interface-architect.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Nixus (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Nixus báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
