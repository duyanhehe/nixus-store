# Nguồn của agent `agency-security-penetration-tester`

Một agent lẻ của gói `nixus.agency-agents`, lấy từ [msitarzewski/agency-agents/security/security-penetration-tester.md](https://github.com/msitarzewski/agency-agents/blob/main/security/security-penetration-tester.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Nixus (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Nixus báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
