# Native, managed, and packaged artifacts

For release comparisons on one MCP connection, retain `list_procedures` Evidence
from each target and reuse its exact IDs after target switches or `close_binary`.
For a handoff or new process, export the complete bundle and import it there,
including its source closure. `reset_investigation` explicitly clears retained
records; optional `save_path` checkpoints them before clearing.
`match_native_functions` pairs unique exact names and, when supplied,
complete observed body bytes. Reuse optional same-context `list_names`,
`procedure_info`, `read_bytes` and existing `analyze_function` dossiers as
`left_observations`/`right_observations`; an MCP `analyze_function` summary
reply contributes its `parent_evidence_id` as a `retained-evidence` reference,
not the summary itself. Avoid decompiling every function merely to match it. Its summary retains a parent for
`inspect_analysis_view` `function-matches` collections `matches` and `functions`.
Select columns, batch IDs and page individual facts; aliases remain unresolved.
Unpaired observations do not prove additions/removals. Existing matched dossier
pairs include inputs for `compare_functions`; otherwise analyze just chosen pairs.

Aggregate completed comparisons with `find_changed_behavior`, selecting each
comparison's exact `retained-evidence` ID instead of resending full records.
Inline comparison Evidence remains accepted. References belong to the current
server: after handoff, import the original bundle including its source closure.
Do not substitute dossier IDs or summary views. Static differences remain
behavior candidates, with runtime behavior unknown unless separately observed.

For a matching representation refusal, inspect `details.limit` and raise
`native.matching_representation_bytes` with `update_analysis_settings` before
retrying the unchanged MCP request. CLI launch seed:
`REA_NATIVE_MATCHING_REPRESENTATION_BYTES`. The default is 96 MiB; the policy
range is 1 byte to 1 GiB and does not bound process RSS. Keep the complete
inventories: splitting them changes global name/body uniqueness.

## Apple app resources

Use `open_bundle_resources` with the selected app path, then `inspect_plist`,
`decode_interface_builder`, `inspect_asset_catalog`, or `inspect_keyed_archive`.
The resource session reads the app without resolving `CFBundleExecutable` or
starting a deep provider. Preserve `resource_root` provenance, per-resource
hashes where reported, and null executable identity; a directory path is not
an executable digest. Export retained Evidence before closing or switching
roots. Binary analysis snapshots do not apply. Use `open_binary` to switch to
executable analysis, and `close_binary` to release either session kind.

The four matching CLI commands accept the app path directly. For an archive
inside the app, use `inspect-keyed-archive APP_PATH RELATIVE_ARCHIVE_PATH`.
Host requirements for plist and compiled asset/Interface Builder tooling still
apply; a resource-only session does not establish provider availability.

## Desktop installation directories

When an installation directory is supplied and its runtime is unknown, use
`inspect_desktop_application` with its absolute path. Default MCP summary
delivery retains complete Evidence. Read `files`, `omissions`, `candidates`, `components` or
`next_probes` with `inspect_analysis_view` kind `desktop-application`, selecting
exact paths, batched file/omission IDs or families and only needed fields and pages.
Summary `probe_issues` retains counts and bounded previews. Select files with
`has_issues: true` and fields `path`, `read_status`, `issues` to retrieve exact
failures directly; preview text is display data, while `file_id` selects full facts. Preserve source
coverage, read-range identity and unknowns; directory snapshot identity is not
a digest of every file's contents. Component path markers do not establish
runtime presence. For compact CLI output, use
`inspect-desktop-application PATH --detail summary --evidence_output BUNDLE`.
See [desktop installations](https://github.com/morluto/rea/blob/main/docs/desktop-applications.md).

## Release exposure

Use `audit_release_exposure` (`rea audit-release-exposure PATH`) when the question is what static analysis of a shipped `.app`, install directory, ASAR, or executable recovers. Each check has a stable id, a status, the observation behind it, and fixed remediation. Unknown and unassessed checks stay in the report. The report does not establish that the application is secure.

`text.credential_markers` reports a rule id and location only. Matched bytes, previews, lengths, and hashes of matched bytes are omitted.

`native.hardening`, `macho.hardened_runtime`, and `android.manifest` are not assessed here. Their next probes are `inspect_binary_hardening`, `inspect_signature`, and `inspect_android_package`.

See [release exposure](https://github.com/morluto/rea/blob/main/docs/release-exposure.md).

## Go build metadata

Use `inspect_go_binary` for an explicit local ELF, PE or Mach-O (universal
files need `architecture`) when the
question concerns the embedded compiler version, module/dependency versions,
local replacements, build settings, or static Go string literals packed without
NUL terminators. Pass `include_string_literals: true`
(`--include-string-literals`, optional `max_string_literals` /
`--max-string-literals`) to recover bounded inferred word-aligned `(ptr, len)`
UTF-8 string slices from read-only data and page them through `go`
`string_literals` views. No `open_binary`, Go installation or
target execution is required. The CLI equivalent is `inspect-go-binary PATH`.
Preserve artifact SHA-256, original file ranges, framed module bytes and every
unparsed module-text line. A missing record is an unknown, not proof of a
non-Go binary; observed metadata does not authenticate its claims, and static
`(ptr, len)` string recovery excludes compiler-inlined stack/immediate strings
without proving runtime reachability. Function,
source and type recovery remain a separate native-analysis question. For a
scanner, project the retained parent with `inspect_analysis_view` kind
`cyclonedx`. That document is CycloneDX 1.6, reads no target bytes, and states
`compositions` as incomplete or unknown. See
[CycloneDX dependencies](https://github.com/morluto/rea/blob/main/docs/guides/native/cyclonedx-view.md).

## Model files

Use `inspect_model_artifact` (`inspect-model-artifact PATH`) for local GGUF v2/v3
and safetensors declarations without a model runtime. Header-only mode does not
read weights or establish full-file identity. `hash: "full"` explicitly streams
all bytes. Retained `model-artifact` views page `metadata`, `tensors` and derived
`types`, with exact batch filters and selected fields. Arrays retain typed counts
and eight-element previews; omitted values, unknown types and runtime behavior
stay explicit. See [model files](https://github.com/morluto/rea/blob/main/docs/model-artifacts.md).

## IL2CPP metadata

Use `inspect_il2cpp_metadata` for an explicit local Unity `global-metadata.dat`
(versions 24, 27, 29, 31 and 39) when the question concerns assembly images,
names, member owners, string literals, namespaces or index ranges. No `open_binary`, Unity installation or target
execution is required. The CLI equivalent is `inspect-il2cpp-metadata PATH`.
MCP defaults to counts with complete retained Evidence. Query `sections`,
`images`, `types`, `methods`, `fields`, `properties`, `events`, `parameters` or
`string_literals` through `inspect_analysis_view`; use exact names,
batch indices and selected fields. Row indices are scoped by artifact SHA-256
and collection; page offsets count filtered matches. Parameters support batch
`method_indices` to read one method's parameters directly. Historical reports
without member collections retain unknown counts rather than empty inventories. Preserve
artifact SHA-256 and index widths. Unrecognized magic may mean encryption and
is unsupported, not decrypted. Linking names to `GameAssembly` or
`UnityFramework` code addresses remains a separate native-analysis question.
See [IL2CPP metadata](https://github.com/morluto/rea/blob/main/docs/il2cpp-metadata.md).

## Rust dependency metadata

Use `inspect_rust_binary` for an explicit local ELF, PE, Mach-O (universal
files need `architecture`), or WebAssembly core module when the question
concerns the cargo-auditable crate list embedded in `.dep-v0` (Mach-O:
`__DATA,.dep-v0`; WebAssembly: a custom section). No `open_binary`, Rust
installation, or target execution is required. The CLI equivalent is
`inspect-rust-binary PATH`. Preserve artifact SHA-256, package order,
dependency indices, and the section file range. A missing section is null
metadata, not proof the binary has no dependencies. An omitted package kind
stays null. WebAssembly reports `bits: null` on a `32 | 64 | null` word size;
null means the container declares no word size and must not be coerced to a
number. ELF, PE and Mach-O stay 32 or 64. Components such as
`wasm32-wasip2` output are unsupported. A rustc commit hash is inferred from a
`/rustc/<40-hex>/` path in read-only data or a WebAssembly data section and
does not by itself identify the compiler. Project the retained parent with `inspect_analysis_view`
kind `cyclonedx` for one CycloneDX 1.6 document. Build-kind packages are
`scope: excluded`. See [Rust binaries](https://github.com/morluto/rea/blob/main/docs/rust-binaries.md)
and [CycloneDX dependencies](https://github.com/morluto/rea/blob/main/docs/guides/native/cyclonedx-view.md).

## Maven POM and Gradle module metadata

Use `inspect_maven_gradle_metadata` for an explicit local Maven `pom.xml` or
Gradle `.module` file when the question concerns declared coordinates,
dependency scopes and exclusions, BOM or platform constraints, or unresolved
property and parent references. No `open_binary`, Maven, Gradle, or repository
access is required. The CLI equivalent is `inspect-maven-gradle-metadata PATH`.
Preserve artifact SHA-256, versions as spelled, and `unresolved` entries.
Interpolation and inheritance are not performed. A missing version is not a
resolved BOM selection. See
[Maven POM and Gradle module metadata](https://github.com/morluto/rea/blob/main/docs/maven-gradle-metadata.md).

## PE Authenticode certificate tables

Use `inspect_pe_certificates` for an explicit local PE32/PE32+ image when the
question concerns the Authenticode certificate table, WIN_CERTIFICATE types, or
embedded PKCS#7 signer and X.509 identity fields. No `open_binary`, Windows SDK,
or target execution is required. The CLI equivalent is
`inspect-pe-certificates PATH`. Preserve artifact SHA-256, table file ranges,
payload hashes, original validity-time spellings, and
`subject_key_identifier_hex` when the signer uses that form. A missing
`IMAGE_DIRECTORY_ENTRY_SECURITY` directory is observed absence of that table,
not proof the image is unsigned in every catalog or overlay sense. Signatures,
chains, timestamps, and Authenticode digest coverage remain unobserved. See
[PE Authenticode certificate tables](https://github.com/morluto/rea/blob/main/docs/pe-certificates.md).

## PE import and delay-load tables

Use `inspect_pe_imports` for an explicit local PE32/PE32+ image when the
question concerns imported DLL and function names, ordinals, delay-load
descriptors, or the pefile import hash. No `open_binary`, Windows SDK, or
target execution is required. The CLI equivalent is `inspect-pe-imports PATH`.
Preserve artifact SHA-256, directory file ranges, original DLL spellings, and
ILT/IAT RVAs. A missing `IMAGE_DIRECTORY_ENTRY_IMPORT` directory is observed
absence of that table, not proof the image never imported APIs through another
table or overlay. Bound snapshots, loaded IAT contents, and export-forward
resolution remain unobserved. See
[PE import and delay-load tables](https://github.com/morluto/rea/blob/main/docs/pe-imports.md).

## Windows Shell Link shortcuts

Use `inspect_windows_shortcut` for an explicit local `.lnk` file when the
question concerns the recorded target path, arguments, working directory, icon
location, volume serial, network share names, ExtraData blocks, or Tracker
droid identifiers. No `open_binary`, Windows SDK, COM, or target execution is
required. The CLI equivalent is `inspect-windows-shortcut PATH`. Preserve
artifact SHA-256, FILETIME raw decimals, IDList type bytes, and ExtraData
signatures. Unknown IDList items and ExtraData signatures remain raw with
SHA-256; they are not guessed. Version-1 UUID MAC and timestamp values are
labelled derived. A missing optional section is observed absence of that
structure. See
[Windows Shell Link shortcuts](https://github.com/morluto/rea/blob/main/docs/guides/native/windows-shortcut.md).

## PE TLS callbacks and load configuration

Use `inspect_pe_load_config` for an explicit local PE32/PE32+ image when the
question concerns code that runs before the entry point through TLS callbacks,
or the security cookie, SafeSEH, CFG, EH-continuation and XFG declarations in
the load configuration. No `open_binary`, Windows SDK, or target execution is
required. The CLI equivalent is `inspect-pe-load-config PATH`. Preserve artifact
SHA-256, directory and callback-array file ranges, and callback VAs as
hexadecimal strings. Fields outside the declared `Size` are `null`. Guard-flag
mitigations carry `evidence_kind: "inferred"`; enforcement remains unobserved.
See
[PE TLS callbacks and load configuration](https://github.com/morluto/rea/blob/main/docs/pe-load-config.md).

## PE x64 exception-directory function ranges

Use `inspect_pe_unwind_ranges` for an explicit local x64 PE32+ image when the
question is where functions start and end without a PDB, or whether a
provider's procedure inventory agrees with the compiler's records. The CLI
equivalent is `inspect-pe-unwind-ranges PATH`. Primary entries start functions;
chained entries are fragments of the entry named by `primary_index`, not
separate functions. Leaf functions have no entry, so a missing entry is not
absence. Compare provider addresses minus `image_base` with the RVAs. See
[PE x64 exception-directory function ranges](https://github.com/morluto/rea/blob/main/docs/guides/native/pe-unwind-ranges.md).

## Mach-O function starts and data in code

Use `inspect_macho_function_starts` for an explicit local thin Mach-O, or one
slice of a universal Mach-O, when the question is which addresses the linker
recorded as function starts, or which bytes inside code are jump tables or
literal data. Pass `architecture` for a universal file. The CLI equivalent is
`inspect-macho-function-starts PATH`. Starts are absolute VM addresses from
`LC_FUNCTION_STARTS` (ULEB128 deltas from the `__TEXT` vmaddr). Data-in-code
entries name offset, length, kind (`DICE_KIND_DATA`, `JUMP_TABLE8`,
`JUMP_TABLE16`, `JUMP_TABLE32`, `ABS_JUMP_TABLE32`, or the numeric kind), and
the function start that owns the address. Page with `offset` and `limit`.
Counts cover every entry. A stripped image can still carry these tables. The
reader does not disassemble. See
[Mach-O function starts and data in code](https://github.com/morluto/rea/blob/main/docs/guides/native/macho-function-starts.md).

## PE overlay

Use `inspect_pe_overlay` for an explicit local PE32/PE32+ image when the
question concerns bytes appended after the image: where the image ends on
disk, whether an overlay is present, and how much of that span is the
Authenticode certificate table. No `open_binary`, Windows SDK, or target
execution is required. The CLI equivalent is `inspect-pe-overlay PATH`.
Preserve artifact SHA-256, image end, and each range's file offset and size.
`certificate_table` is the security directory when it lies entirely in the
overlay. A security directory that fails certificate-table checks, such as an
unaligned offset, or that starts inside the image and ends in the overlay,
stays in other ranges and adds a limitation. Each other range includes SHA-256, a fixed 4096-byte Shannon entropy
sample, the first 16 bytes, and a leading format only when an existing
recognizer names one. Packers are not identified. Signatures, chains, and
digest coverage are not verified. Section slack inside the image is not
reported as overlay. Image end uses each section's declared PointerToRawData
plus SizeOfRawData; the loader's 512-byte rounded pointer is recorded per
section and does not shorten that end. See
[PE overlay](https://github.com/morluto/rea/blob/main/docs/guides/native/pe-overlay.md).

## Binary hardening

Use `inspect_binary_hardening` for an explicit local ELF, PE, or Mach-O file
when the question concerns PIE or ASLR, NX, RELRO, stack-protector or FORTIFY
signs, control-flow flags, or stripped state. No `open_binary`, pwntools, or
target execution is required. The CLI equivalent is
`inspect-binary-hardening PATH`. Universal Mach-O files return one image per
slice. A missing import is `unknown`, not proof the protection was omitted.
Authenticode and Mach-O code-signature rows report presence, not validity.
`hardened_runtime` stays unknown and names `inspect_signature`. See
[binary hardening](https://github.com/morluto/rea/blob/main/docs/binary-hardening.md).

## ELF note tables

Use `inspect_elf_notes` for an explicit local ELF32/ELF64 image when the
question concerns PT_NOTE/SHT_NOTE owners or supported note metadata. Treat
FDO package and dlopen fields as producer declarations. No `open_binary` or target execution is required. The CLI equivalent
is `inspect-elf-notes PATH`. Preserve artifact SHA-256, table file ranges,
descriptor hashes, and original owner spellings. A missing table is observed
absence of those declarations, not proof the image never carried notes in
another container. See
[ELF note tables](https://github.com/morluto/rea/blob/main/docs/elf-notes.md).

## DWARF compile units

Use `inspect_dwarf_units` for an explicit local ELF, Mach-O, or PE image when
the question concerns compile-unit source file, compilation directory,
producer, language, or split-DWARF `dwo_name`. No `open_binary` or target
execution is required. The CLI equivalent is `inspect-dwarf-units PATH`. For a
`.dSYM` bundle, pass the DWARF file inside the bundle; the bundle itself is
not opened. Universal Mach-O requires `architecture`. Preserve artifact
SHA-256, section file ranges, and per-unit issues. Absent `.debug_info`
describes this file only and does not establish that a separate debug file is
absent. Partial coverage includes a declared `.debug_info` that was not read,
such as an undecodable section or a `.dwo` object. A present `.gnu_debuglink` is named and not decoded. Child DIEs,
types, line tables, and location expressions are not read. See
[DWARF compile units](https://github.com/morluto/rea/blob/main/docs/guides/native/dwarf-units.md).

## ELF debug files

Use `inspect_elf_debug_link` for an explicit local ELF32/ELF64 image when the
question concerns `.gnu_debuglink`, `.gnu_debugaltlink`, the GNU build-id, or
whether one selected file matches that linkage. No `open_binary` or target
execution is required. The CLI equivalent is `inspect-elf-debug-link PATH`,
with optional `--candidate-path`. Preserve artifact SHA-256, debuglink CRC32,
build-id hex, and the returned lookup path strings. Those strings are not
opened, and a same-directory path is not listed. Pass `candidate_path` only
for a file you already chose. The verdict compares debuglink CRC32 and GNU
build-id; the alt-file build-id is not that comparison. A missing named
section is observed absence only when section names are complete. The
`.gnu_debugdata` xz payload is not decoded. See
[ELF debug files](https://github.com/morluto/rea/blob/main/docs/guides/native/elf-debug-link.md).

## ELF dynamic dependencies

Use `inspect_elf_dependencies` for an explicit local ELF32/ELF64 `ET_EXEC` or
`ET_DYN` image when the question concerns needed libraries, SONAME, rpath /
runpath, GNU symbol versions, or undefined dynamic imports. No `open_binary`,
dynamic loader, or `ldd` is required. The CLI equivalent is
`inspect-elf-dependencies PATH`. Preserve artifact SHA-256, `DT_NEEDED` order
and duplicates, search-path tokens as written, decoded `DT_FLAGS` /
`DT_FLAGS_1`, `PT_INTERP`, GNU version names, and `library@version` joins when
`.gnu.version` names a verneed record. `$ORIGIN`, `$LIB`, and `$PLATFORM` are
not expanded. A missing `PT_DYNAMIC` is observed absence of that inventory,
not proof the image never needed libraries in another container. Relocatable
objects use `inspect_kernel_module`. Core dumps use `inspect_recorded_crash`.
See
[ELF dynamic dependencies](https://github.com/morluto/rea/blob/main/docs/elf-dependencies.md).

## ELF and Mach-O initializer functions

Use `inspect_native_initializers` for an explicit local ELF or Mach-O image
when the question is which functions run before `main` or at exit: ELF
`DT_PREINIT_ARRAY`, `DT_INIT`, `DT_INIT_ARRAY`, `DT_FINI`, `DT_FINI_ARRAY` and
legacy `.ctors`/`.dtors`, or Mach-O `__mod_init_func`, `__init_offsets` and
`__mod_term_func`. Pass `architecture` for a universal Mach-O. The CLI
equivalent is `inspect-native-initializers PATH`. PIE slots are resolved
through RELATIVE, RELR and section relocations, and Mach-O slots through
chained fixups. Keep each entry's `resolution`: `unresolved` means the value was
not established, and `unresolved_import` names an external symbol. Page with
`offset` and `limit`. See
[ELF and Mach-O initializer functions](https://github.com/morluto/rea/blob/main/docs/guides/native/native-initializers.md).

## ELF unwind function ranges

Use `inspect_elf_unwind_ranges` for an explicit local ELF32/ELF64 image when
the question concerns function starts and lengths that survive `strip`, which
functions have an LSDA, or which ranges have no exact symbol. No
`open_binary` or target execution is required. The CLI equivalent is
`inspect-elf-unwind-ranges PATH`. Preserve artifact SHA-256, FDE start and
end, containing section, exact symbol name, CIE index, LSDA, and personality.
Page later ranges with `offset` and `limit`. A missing `.eh_frame` is
observed absence of that declaration and of `PT_GNU_EH_FRAME`, not proof the
image has no functions. Header disagreement is a limitation and does not drop
decoded ranges. `.debug_frame` is reported present or absent and is not
decoded. CFA instructions are counted and not evaluated. Indirect EH pointers
are not dereferenced. See
[ELF unwind function ranges](https://github.com/morluto/rea/blob/main/docs/guides/native/elf-unwind-ranges.md).

## Apple IPS crash reports

Use `inspect_apple_ips` for an explicit local Apple `.ips` file when the
question concerns crash metadata, exception and termination facts, threads,
usedImages, lossless registers, or documented crash classes. No `open_binary`,
Xcode, atos, or target execution is required. The CLI equivalent is
`inspect-apple-ips PATH`. Preserve artifact SHA-256, `bug_type` as a string,
uppercase image UUIDs, and integer literals that exceed IEEE-754 range. Only
`bug_type` `"309"` yields a crash body; other DiagnosticReports types return
no crash result. Select `join_path` for one local Mach-O or dSYM to match
report images to slices by UUID and architecture. Preserve the selected
artifact identity, slice facts and unjoined reasons; a joined static address
does not resolve function names or dSYM symbols. See
[Apple IPS crash reports](https://github.com/morluto/rea/blob/main/docs/apple-ips.md).

## Linux kernel modules

Use `inspect_kernel_module` for an explicit local ELF32/ELF64 relocatable
object when the question concerns `.modinfo` license, vermagic, alias,
depends, or parm strings, the `__versions` symbol CRCs, or an appended module
signature trailer. No `open_binary`, Linux host, or `modinfo` program is
required. The CLI equivalent is `inspect-kernel-module PATH`. Preserve
artifact SHA-256, key order, duplicate keys, CRC hex, and section file ranges.
A missing section is observed absence when section names are known, not proof
the module never carried that metadata. `.gnu.linkonce.this_module` is reported
as present or absent; `struct module` stays unknown because its layout changes
with the kernel version. `__ksymtab` records are not decoded. The PKCS#7 range
and its SHA-256 are observed; certificate, signer, and digest coverage remain
unvalidated. An absent trailer is not proof the module is unsigned in another
container. gzip, xz, and zstd whole-file containers are unsupported and name
`external_decompression` as the next probe: use an external codec utility to
decompress into a separate file, then call `inspect_kernel_module` on that file. See
[Linux kernel modules](https://github.com/morluto/rea/blob/main/docs/kernel-modules.md).

## Linux kernel build config

Use `inspect_kernel_build_config` for an explicit local kernel image (`vmlinux`
ELF, raw arm64 `Image`, x86 `bzImage`/`zImage`, or `configs.ko`) when the
question is which kernel version it is or how it was configured. No
`open_binary`, Linux host, or `extract-ikconfig` is required. The CLI
equivalent is `inspect-kernel-build-config PATH`; pass `name` for one exact
`CONFIG_*` option and `offset`/`limit` to page the rest. Preserve the banner
version, builder, and compiler, the config SHA-256 and option count, and each
entry's value kind (`y`, `m`, `string`, `number`, `not_set`). A config is
accepted only when `IKCFG_ST` is immediately followed by a valid gzip member
and `IKCFG_ED`, so an ordinary `IKCFG_ST` string is not a config. Offsets with
`space: "inflated_payload"` are positions in an inflated bzImage payload, not
file offsets. An absent config describes only the searched bytes; the kernel
may have been built without `CONFIG_IKCONFIG` or with it as a module. Truncated
payloads are incomplete, not absent. A framed blob that does not decode, has a
bad CRC, or holds non-config text is `malformed`, not absent. xz, lz4, lzma, zstd, bzip2, and lzo
payloads are unsupported and name `external_decompression`: decompress with an
external utility, then call `inspect_kernel_build_config` on the result. See
[Linux kernel build config](https://github.com/morluto/rea/blob/main/docs/guides/native/kernel-build-config.md).

## CPython pyc files

Use `inspect_python_pyc` for an explicit local CPython 3.7–3.15 `.pyc` when the
question concerns the header magic, PEP 552 source hash or timestamp, nested
code-object names, or bytecode identity. No `open_binary`, Python installation,
or target execution is required. The CLI equivalent is `inspect-python-pyc PATH`.
Preserve artifact SHA-256, the 16-byte header fields, nested code names, and
bytecode SHA-256. Bytecode is not decompiled. A decoded header does not prove
the matching `.py` is present. See [CPython pyc inspection](https://github.com/morluto/rea/blob/main/docs/python-pyc.md).

## Debian packages

Use `inspect_deb_package` for an explicit local `.deb` when the question
concerns ar members, control identity, relationship alternatives, maintainer
script presence, or the data.tar inventory. No `dpkg`, package installation,
or target execution is required. The CLI equivalent is
`inspect-deb-package PATH`. Preserve artifact SHA-256, the debian-binary
version, parsed relationship operators and architecture qualifiers, script
interpreter lines and byte lengths, and md5sums path presence. Script text is
not returned and is never executed. gzip, zstd, xz, and uncompressed members are
decoded; bzip2 and lzma members are unsupported. Package signatures are
not verified. Missing optional fields stay null. See
[Debian package inspection](https://github.com/morluto/rea/blob/main/docs/deb-package.md).

## Erlang BEAM files

Use `inspect_erlang_beam` for an explicit local `FOR1`/`BEAM` file when the
question concerns IFF chunks, atom names, exports, imports, lambdas, or the
Code header. No `open_binary`, Erlang installation, or bytecode execution is
required. The CLI equivalent is `inspect-erlang-beam PATH`. Preserve artifact
SHA-256, chunk file ranges, 1-based atom indices, and original atom spellings.
Missing optional tables stay null. For a few facts, use `detail: "summary"` with
a `beam` view selecting a collection, exact names/indices and fields; read later
pages from `parent_evidence_id` or the complete Evidence bundle. Same-name
exports retain every arity and original atom index. CLI summary delivery requires
`--evidence_output`. Null table counts remain distinct from decoded empty tables. See
[Erlang BEAM files](https://github.com/morluto/rea/blob/main/docs/erlang-beam.md).

## NuGet packages

Use `inspect_nuget_nupkg` for an explicit local `.nupkg` when the question
concerns package identity, license, repository, dependency groups, or the ZIP
contents inventory. No `open_binary`, restore, feed access, or target execution
is required. The CLI equivalent is `inspect-nuget-nupkg PATH`. Preserve artifact
SHA-256, `.nuspec` fields as present, dependency version ranges as spelled, and
path-derived member roles (`lib`, `ref`, `runtimes`, and the other NuGet folder
conventions). Missing, ambiguous, or malformed `.nuspec` members succeed with
inventory and limitations. Encrypted members are listed and not extracted.
Roles are folder conventions, not restore-time asset selection. See
[NuGet packages](https://github.com/morluto/rea/blob/main/docs/guides/managed/nuget-nupkg.md).

## VS Code extension packages

Use `inspect_vsix_package` for an explicit local `.vsix` when the question
concerns package identity from `extension.vsixmanifest` and
`extension/package.json`, engine range, activation events, contributes,
declared dependencies, native/wasm/executable members, or signature-file
presence. No `open_binary`, install, marketplace access, or target execution
is required. The CLI equivalent is `inspect-vsix-package PATH`. Preserve
artifact SHA-256, both manifests as present, identity disagreements, and
hashed interesting members with observed vs inferred classification. Missing
or malformed manifests succeed with inventory and limitations. Encrypted
members are listed and not extracted. Signature files are reported present or
absent and are not verified. See
[VS Code extension packages](https://github.com/morluto/rea/blob/main/docs/guides/managed/vsix-package.md).

## OCI image layouts

Use `inspect_oci_image_layout` for an explicit local OCI image-layout directory
(`oci-layout`, `index.json`, `blobs/<alg>/<hex>`) when the question concerns
layout version, index entries, image config, layers, or blob digest
verification. No `open_binary`, registry access, layer decompression, or
target execution is required. The CLI equivalent is
`inspect-oci-image-layout PATH`. Preserve snapshot identity, descriptor digests,
and Env names and values; set `include_env_values` to false to omit the values.
Missing blobs, digest mismatches, size mismatches, unreferenced blobs, unknown
media types, unsupported digest algorithms, and symlink blobs are findings.
Child symbolic links are not followed. Directory form only; tar image layouts
are not inspected. See
[OCI image layouts](https://github.com/morluto/rea/blob/main/docs/guides/artifacts/oci-image-layout.md).

## YARA rule matches

Use `inspect_yara_matches` when the caller supplies YARA rule files and asks
which rules match one explicit local file. It runs the installed `yara` command
(`REA_YARA_COMMAND` or `yara` on `PATH`) with an argument list, never a shell,
and needs no `open_binary`. REA ships no rules and downloads nothing; do not
write or fetch rules unless asked. The CLI equivalent is
`inspect-yara-matches PATH --rule_paths RULE`. Cite the file SHA-256 and each
rule file SHA-256 with the matched rules, tags, meta, and string offsets.
`data` is yara's display text; read `length` bytes at `file_offset` for exact
bytes. `coverage.status: "partial"` means string matches beyond `max_matches`
are counted but unlisted; raise `max_matches` to list them. A compile error is
`invalid_request` naming the rule file; fix the rule rather than retrying. A
missing command is `capability_unavailable`. Absent rules did not match; that
says nothing about why. See
[YARA rule matches](https://github.com/morluto/rea/blob/main/docs/guides/native/yara-matches.md).

## SQLite snapshots

Use `inspect_sqlite_database` with an explicit local database snapshot for its
schema and optional rows from one exact ordinary table. It needs the native
`DatabaseSync.limits` API, so it is unavailable when REA runs on Node.js 22.x. It also consumes the
existing sibling `-wal`; retain both original digests when citing its result.
Default output is a compact inventory; a selected table expands only its own
schema and samples 20 rows. Select `columns` to avoid irrelevant or large cells,
and request `schema_scope: "database"` only for complete schema details.
Choose `row_limit` when a finite sample is useful and keep truncation and
unspecified row order explicit. Virtual tables, shadow tables and views are
schema facts, not row-read targets. REA inspects private copies and leaves
the source files untouched; obtain a coherent quiescent database/WAL snapshot
before inspection. See [SQLite snapshots](https://github.com/morluto/rea/blob/main/docs/guides/data/sqlite-databases.md).

## Recorded Linux crashes

Use `inspect_recorded_crash` with an explicit Linux x86-64 ELF core path to
inspect historical thread registers, signals, raw notes and original file
ranges. It is independent of the active disassembler target. Source-bound
register values and note bytes are observations; missing notes, signal-thread
association and current executable/library identity remain unknown. PIDs are
historical metadata and never authorize live attach or control.

The optional `include_debugger_context` facet adds mapping candidates through
caller-supplied GDB/pwndbg in an owned core-only session. Display names do not
establish current file identity; zero reported flags leave permissions unknown.
Requested unavailable context fails with setup guidance. See
[recorded crashes](https://github.com/morluto/rea/blob/main/docs/guides/native/recorded-crashes.md)
for exact upstream profiles, bounds and verification coverage.

## Offline ELF layout

Use `inspect_binary_layout` with an explicit local ELF path for file-backed
sections, symbols, relocations, linkage names, and static mitigation inferences
without opening a disassembler target. When that complete record is already
retained, call `inspect_analysis_view` for a summary, mitigations or linkage
facet, one section or symbol, or a stable page. Do not re-run the decoder to
read a single object.

## Offline WASM

Use `inspect_wasm_artifact` with caller-supplied WABT for selected local bytes.
For counts, validation and WAT identity, select `detail: "summary"` on the first
MCP call. The complete original Evidence stays retained; use
`normalized_result.parent_evidence_id` for exact exports or text pages. Omitted
or complete detail keeps the existing complete result.
For a completed result, use `inspect_analysis_view` with its reported retained
reference for a summary or `view: {kind: "wasm", facet: "exports", offset: 0, limit: 32}`.
Facets also include sections, imports, candidates, glue, WAT, headers, details
and tool profile. Text offsets count UTF-16 code units; follow `next_offset`.
The complete source remains retained after an oversized MCP reply. No target
execution or network acquisition is implied, and WAT is decoded representation.

For exact core-module import/export differences, use `compare_wasm_interfaces`
with two complete inspection Evidence records (or current-session retained
references) and explicit scope. Preserve unknown types/duplicate names; static
interface equality is not runtime compatibility. CLI accepts complete inline
Evidence in `rea compare-wasm-interfaces input.json --json`, or exact references
with `--evidence-bundle /absolute/path/evidence.json`. Use the complete parent
ID when the inspection returned a summary.

## Offline APK signatures

Use `inspect_apk_signature` for a selected local APK/ZIP/AAB. Default MCP summaries
retain complete Evidence. Select `view.collection: signers/digests/lineage`,
with scheme or ID batches, fields and paging; use `inspect_analysis_view` kind
`apk-signature` for retained reads after deletion. IDs retain artifact/scheme
scope and signer links; `fields: []` keeps identity links. Empty pages preserve
partial decoding reasons and unknown authenticity. CLI compact delivery needs
`--evidence_output` to preserve the complete parent.
It reads the APK
Signing Block (v2/v3/v3.1) and v1 `META-INF` signing without executing anything,
and reports each signer's certificate facts (for v1, the certificate the PKCS#7
block's SignerInfo names), the declared v3 rotation lineage,
the declared source-stamp certificate and, for SHA-256/SHA-512 digests, whether
the declared content digest matches the current bytes. That match is not a
signature verification: anyone who changes the bytes can recompute the digest.
`posture` summarises v1-only signing (which cannot tell a v1-only APK from one
whose v2/v3 block was removed), observed signer agreement across schemes,
whether the v1 signer equals the block-scheme signer (`false` is notable),
whether every differing signer appears in a declared (unverified) rotation
lineage, and the strongest scheme.
It never claims authenticity: no signature or lineage is cryptographically
verified.

## Native targets

After `open_binary`, use focused search, procedure, or function tools directly.
Use `binary_overview` when target metadata or inventory context helps answer the
question. Prefer literal search, names, decompilation, callers, callees, and
cross-references. Addresses and recovered pseudocode are analysis observations,
not original source. Provider unavailability and unsupported metadata remain
unknown rather than false.

For large pseudocode, request `procedure_pseudo_code` with `detail: "summary"`
on the first MCP call. It retains the complete observation and returns the
original selection, text availability and length without the body. Use
`normalized_result.parent_evidence_id` with `inspect_analysis_view` and
`view: {kind: "native", facet: "pseudocode", offset: 0, limit: 20000}`;
follow `coverage.next_offset` for later pages. Choose a smaller limit if one
page exceeds the client or transport budget. Offsets and limits count UTF-16
code units, not lines or tokens. Pages reuse the same observation without
repeating decompilation. Null and empty text remain distinct. Omitted or
`complete` detail preserves full inline delivery. Summary delivery requires a
retaining session and does not reduce the work or memory of decompilation.

For a completed `analyze_function` dossier, use `inspect_analysis_view` with
`view: {kind: "native", facet: "value_flow_operations", offset: 0, limit: 32}`
and the exact retained Evidence ID to read selected facts without reanalysis.
The default MCP reply is already a summary of that dossier: its
`normalized_result.parent_evidence_id` is the retained ID to page, and its
null counts mark facets the provider did not record or declared unavailable.
Native facets also include procedure, pseudocode, assembly, basic blocks,
comments, callers/callees, references, unresolved calls, referenced strings and
names, the native API record, and value-flow summaries. Pseudocode offsets and limits count UTF-16
code units; use the returned `next_offset` for continuation. Provider limitations
and unavailable facts remain explicit; the complete parent Evidence is retained.

`inspect_macho` on a large framework returns megabytes of imports and exports.
Select `detail: "summary"` for slice identity, UUID and per-collection counts,
then page rows with `view: {kind: "macho", facet: "exports", offset: 0, limit: 64}`
and `normalized_result.parent_evidence_id`. Facets are entrypoints,
architectures, build_metadata, load_commands, dependencies, imports, exports,
segments and provenance. `source_exhaustive: false` means unreturned symbols
may exist.

To see which functions or Objective-C methods a Mach-O actually calls in one
run, use `observe_native_calls` with explicit breakpoints and a bounded
`duration_ms`/`max_events`. It launches a new process under LLDB, so the target
runs and may change files or use the network. Hardened-runtime targets need the
`get-task-allow` entitlement.
Function breakpoints use exact LLDB runtime names: pass an `inspect_macho` export
or import `runtime_name` (`main`), not its symbol-table `name` (`_main`). REA does
not translate breakpoint names. Set `module` to the image
file name when selecting that image only; otherwise loaded system images also
match. Inspect retained locations and module paths before attributing a call.

Use `binary_session` with no arguments to check the open target, selected
provider, and alignment. Its default summary `result.tool_availability` carries
the complete tool inventory grouped by current status. Expand each group's
`names` and inherit the inventory-level client requirements unless a group
overrides them; availability, reasons, remediation, and modes remain inline.
Provider candidates keep availability and target-support status, code, and
reason. `omitted_fields` names what the summary leaves out; `{"detail":
"complete"}` adds each unavailable candidate's `remediation`, provider
diagnostics, candidate capability sets, and tool surface, `effects`, and
`annotations`. Those arrays name true flags from fixed
vocabularies, so an omitted known flag is false. `tools/list` remains the
canonical source for full tool schemas when target or provider state changes.

Provider capability groups carry provider identity and ordered limitations.
Prepend each set's `shared_limitations` to a group's `limitations` to recover the
operation's full ordered list. Candidate capabilities, returned with complete
detail, describe possible providers. Top-level session capabilities describe the current route, and
`analysis_provider_binding` identifies the selected provider.

## Continue editable Ghidra analysis across processes

For a task spanning agent sessions, check `binary_session` after selecting
Ghidra: the current provider's `capabilities[].shared_limitations` states whether
Program checkpoints are enabled or the session is ephemeral. Successful native
queries distinguish initial analysis from an actually restored packed Program;
do not infer that restoration happened merely because checkpoint mode is enabled.

In ephemeral mode, choose a private absolute directory and set
`REA_GHIDRA_CHECKPOINT_DIR` in the environment starting REA. Restart the MCP server
after changing that launch configuration; no current tool call or runtime
analysis-setting update enables it. Stock ELF/PE/Mach-O imports on Linux/macOS
are supported; see the [checkpoint setup and limitations](https://github.com/morluto/rea/blob/main/docs/getting-started/installation.md#automatically-checkpoint-an-owned-ghidra-program).

With the setting enabled, normal opens restore compatible saved Programs
automatically. Initial completed analysis is saved, and `close_binary` saves
later metadata edits; no separate save/restore tool is needed. Repair a reported
save failure and retry close. Cancellation or process failure can lose edits
after the last successful save; unfinished initial analysis cannot resume.
Keep the same checkpoint configuration for later processes. Evidence/Unknown
history and immutable REA query snapshots have separate persistence workflows.

## Reuse caller-selected Ghidra analysis

When the caller supplies an expanded project, configure `REA_GHIDRA_PROJECT_PATH`
(the `.gpr` marker) and optionally `REA_GHIDRA_PROGRAM_NAME` (one root program),
then restart/reconnect before `open_binary`. CLI uses the same configuration.
REA opens only a fingerprint-bound owned copy with `-process -noanalysis -readOnly`;
original project files are not opened by the engine or saved. Database edits,
import overrides and repair scripts are unavailable in this mode. Treat original
analysis completeness/settings as unknown and prior edits as caller-project state.
The program's recorded import digest must match the target; changed project content
requires reopening for a fresh profile. See the
[setup and preparation guide](https://github.com/morluto/rea/blob/main/docs/getting-started/installation.md#reuse-an-existing-ghidra-project).

## Ghidra startup deadline recovery

`provider_timeout` during the first Ghidra query can cover import, auto-analysis,
bridge startup, and readiness. The default 330,000 ms is configurable through
`REA_GHIDRA_STARTUP_TIMEOUT_MS`; a smaller query still needs the same cold import.

When the error names `ghidra.startup_timeout_ms`, call
`update_analysis_settings` with `action: "set"` and a larger value within the
reported bounds. Resolve retained cleanup before the next startup attempt.
No REA restart is needed; an already accepted startup keeps its original
budget. Follow the error's session-specific restart guidance, and preserve useful Evidence before closing
and reopening the target when remediation requires that lifecycle step.

For a per-function timeout, update `ghidra.decompile_timeout_seconds` and retry
the same function on the existing Program. Explicit `null` removes that
per-function deadline. Inspection is optional when the error supplies the
setting and bounds. Runtime updates disappear when REA exits; environment
changes only seed future REA processes.

The client's tool-call deadline must allow startup plus the requested query;
server settings and progress notifications cannot override it. CLI analysis
avoids the MCP client deadline, but retains the provider deadline. For example:

```sh
REA_GHIDRA_STARTUP_TIMEOUT_MS=1800000 rea analyze /absolute/path/to/app.exe --provider ghidra --json
```

Thirty minutes is an example budget, not a completion guarantee. Keep host CPU
and memory controls in place. Disable specific expensive analyzers only when
their missing coverage is acceptable and retain the resulting limitations.
Exported C and embedded resources remain useful independent evidence, but a
timeout does not establish complete analysis or absence of code. See the
[deadline and client guide](https://github.com/morluto/rea/blob/main/docs/reference/mcp-contracts.md#ghidra-first-query-deadlines-and-recovery).

## Bridge request ceiling

Hopper and Cutter share `REA_BRIDGE_MAX_REQUEST_BYTES`. Unset, both sides use
16777216 bytes. The payload budget excludes the terminating LF. A decimal
integer from 7464 to 536870887 raises or lowers that ceiling. The floor fits
the largest bounded symbol-name command. A tight Cutter status still returns
its session id and up to 64 completion receipts. Its path is included when it
fits, and is unknown when it does not, so an older descriptor path is not
paired with the new generation. The maximum is the encoded payload, one byte under Node's string ceiling so
the framing LF still fits. Cutter measures, signs, and writes a fitting
response in bounded chunks. The bridge searches only the newly read bytes
for the framing LF. The client unescapes each socket chunk into one response
string before parsing it, so this ceiling does not keep the paged wire frame
and another concatenated copy. Invalid values are configuration errors and do not fall back to 16777216. `bridge.max_request_bytes` can be changed at runtime with `update_analysis_settings`. The launch seed is `REA_BRIDGE_MAX_REQUEST_BYTES`. Start Hopper or Cutter from that same environment so the bridge keeps the ceiling it started with until that bridge starts again. An out-of-band bridge
without the setting stays at 16777216 bytes. The client reports that mismatch
during discovery only after the hello proves a live authenticated bridge, and
does not send a status request or the command. A stale descriptor is ignored.
Discovery fails if any such live ceiling differs, even when another live
session matches. A command response discarded for that ceiling stays an
unknown execution with `output_truncated`. A hello
that never sends its authenticated frame does not hold the accept loop.
At most 8 connection threads run; a further accept is closed, and a failure
to start a thread does not stop the listener. `completed_connection` is the
longest prefix of connections that have terminated. Dense scalar replies are
encoded in bounded batches.
The 25000 ms Cutter request deadline and the 256-candidate discovery budget
still have no runtime override.

## Selected native facts and call graphs

For a large `get_call_graph`, or repeated `procedure_address`,
`procedure_callees`, `procedure_callers` and `resolve_containing_procedure`
queries, select `detail: "summary"` when the first 64 recorded observations
suffice. Read further `native-observation` pages from the returned parent Evidence
ID. Graph message IDs index that page's exact-text dictionary; keep level,
source index, failed nodes, and partial/unknown relationship coverage.
Read referenced source context through `native-context` facets `overview`,
`analysis-profile`, `limitations` and `result-limitations`. Reuse inspected
context/profile values only for the same digest; until caveats are read,
interpretation beyond the returned facts remains unknown. Complete Evidence
remains retained and exportable. Small complete replies can cost fewer tokens
than additional context/page calls; count the completed task and discovery.

## Static memory and original file bytes

For Ghidra, `read_bytes` reads initialized analysis memory, including loader
fixups; it does not read a running process. Check `returned_bytes` and `complete`
before decoding a table. An incomplete read is missing coverage, not a zero-filled
tail. Use `list_segments` to inspect the selected block's initialization and address-space
facts, and retain unavailable facts as unknown.

Use `address_to_file_offset` to anchor one observed address to original file
bytes. A mapping for the first address does not establish a contiguous mapping
for an entire table, and loader fixups can make analysis bytes differ from source
bytes. Keep source ranges and analysis-memory observations separate.

A pointer table can refer to writable slots populated by a constructor rather
than directly to immutable resources. An uninitialized block or an observed zero
does not establish the slot's later runtime value. Follow `xrefs` and the relevant
writer's assembly or pseudocode; distinguish recorded assignments from inferred
execution order. Do not replace unreadable bytes with zeros or conclude that a
resource is absent without the necessary initialization evidence.

## DOS MZ with Ghidra

For an admitted DOS MZ target, use `inspect_native_load_image` to check measured
loaded bytes, file mappings, relocations and the entry against the immutable
snapshot. Keep `mismatch` and `unsupported` explicit. Verified import covers the
reported static image, not runtime DOS or PC-98 hardware behavior.

For a large load-image report, select `detail: "summary"` and query its
`parent_evidence_id` with `inspect_analysis_view` kind `native-load-image`.
Choose a collection such as `relocations` or `mappings`, select only needed
fields, and page with offset/limit. Original indices preserve same-address
alternatives. Null collections remain unrecorded or inapplicable; paging does
not upgrade unsupported verification. CLI requires `--evidence_output` for
summary delivery so complete source Evidence remains accessible.

For Ghidra decompilation, `procedure_pseudo_code` also accepts `procedure: "file-offset:0x..."`; CLI `rea decompile <path> --file-offset=0x... --provider ghidra` resolves the source byte offset internally. An unresolved 0x-prefixed numeric procedure selector also falls back to a unique file mapping. Existing symbols and analysis addresses win; multiple mappings fail as ambiguous. Preserve the returned file-offset and address locations and raw selection observations. ELF virtual addresses are distinct from file offsets; never assume an arbitrary offset plus image base is an analysis address.

Complete function body ranges use inclusive ends and can contain gaps. Do not
treat the enclosing span as code.
For packed targets, retain the original and separately derived artifact identities;
decompiling an unpacking stub does not recover the unpacked program.

When reading Objective-C dispatch metadata, distinguish class implementation
methods from protocol requirements: class methods report null requirement
flags, while decoded protocol declarations retain required and optional facts.
Property attributes remain raw name/value tokens; use the property's
`atomicity` field for the decoded `N` marker or the default atomic behavior.
Null class/meta flags, ivar counts, atomicity, or read-only values mean the
selected provider did not establish that fact. Symbol names alone do not prove
that a class is a root class or has no ivars.

## Managed PE/CLI

Start with `inspect_managed_artifact`. REA's canonical managed inspection is
execution-free: do not claim it loaded, reflected, executed, or resolved the
assembly. Keep managed/native boundaries and unavailable reconstruction facts
explicit. A bring-your-own reconstruction oracle is separate from the canonical
parser and must not become an implicit setup dependency.

For identity/classification questions, `inspect_managed_artifact` can explicitly
select `detail: "summary"` on the first MCP call. It retains complete metadata
and returns a linked overview with full classification/evidence, nullable
module/MVID, frameworks, metadata coverage/issues/limitations and returned-row
counts. Default complete requests remain unchanged. Read original rows with
`inspect_analysis_view`, source `normalized_result.parent_evidence_id`, and
`view: {kind: "managed", collection: "attributes", offset: 0, limit: 16}`.
Collections are `references`, `resources` and `attributes`. Paging does not
repeat parsing. Returned-row exhaustion
does not prove complete metadata or absence under partial/unavailable coverage;
preserve build-local tokens and their artifact/MVID scope.

`inspect_managed_members` always returns the assembly-wide `member_refs`, even
for one selected type. For questions about a selected type, select
`detail: "summary"` with `type_names`; it returns the selection (with unmatched
names), coverage and per-collection counts. Page rows with
`view: {kind: "managed-members", collection: "call_edges", offset: 0, limit: 64}`
over `types`, `exported_types`, `fields`, `methods`, `member_refs`, `call_edges`,
`field_accesses`, `user_strings` or `unresolved_definitions`. The last collection
pages checked TypeDef and MethodDef coordinates with failed name columns.
Use exact `names` and `declaring_types` filters before paging supported
collections. For a compact method lookup, request `fields: ["name",
"declaring_type", "signature"]`; omit `body` to avoid anchors. Identity tokens,
original `source_index`, module/MVID and source coverage remain. Check
`unresolved_filter_rows` before interpreting an empty match as absence.

### .NET NativeAOT

NativeAOT binaries contain native machine code, so ordinary CIL decompilers
cannot recover the original method bodies. When managed metadata/CIL is absent,
classify that as a native-analysis route rather than claiming source recovery.
Open the native image with the selected deep provider and inspect functions,
strings, calls, and references; describe decompiler output as pseudocode and
inference.

NativeAOT images can be PE/COFF, ELF, or Mach-O executables and shared
libraries. Use file bytes and loader metadata rather than suffixes to identify
them. For packaged apps, inventory/extract with REA's artifact tools and retain
the exact contained image identity. PDB, ELF debug, or dSYM sidecars are
additional evidence only when the provider accepts and matches them.

REA has a built-in read-only snapshot parser for x64 PE targets with .NET 8 RTR
9.1 metadata. An optional headless Ghidra adapter adds database annotations and
broader metadata recovery on Linux; it requires an explicitly configured
NativeAOT JAR. These are separate routes. The built-in parser also runs on
Windows Ghidra P0; read frozen literals from its report, because
`search_strings` does not include them. See the
[NativeAOT guide](https://github.com/morluto/rea/blob/main/docs/providers/ghidra-nativeaot.md)
for setup, supported layouts, and host restrictions. Preserve binary identity
and distinguish derived metadata from Ghidra database observations. Recovered
types and native pseudocode are not original C# source. Windows Ghidra P0 has
no database mutation authority.

## Packages and extraction

Use `inspect_artifact` for application bundles, archives, ZIP/APK/IPA/MSIX/AppX,
ASAR, or DMG inputs when the artifact graph and findings help answer the
question. It returns the complete artifact graph inline. Cite graph manifest
IDs when using them.

For an IPA or a macOS `.app`, ZIP, or DMG, pass the inventory Evidence to
`project_apple_application_graph`. It reports application roots and nested
bundles by path convention: app extensions, XPC services, frameworks, login
items, system and driver extensions, and plug-ins. It also lists privileged
helpers, launchd plists, symlinks, and each bundle's `info_plist_path` and
executable candidates. Roles are path conventions, not parsed plists; read the
listed plists with `inspect_plist`.

After `open_binary` on a `.app` or Mach-O, use `trace_dylib_resolution` to see
which file each `@rpath`, `@loader_path` and `@executable_path` load reaches for
every executable in the bundle. It also lists missing or weak loads and earlier
`@rpath` candidates that are absent. Narrow large bundles with `roots` or
`architecture`. System paths stay undetermined because the dyld shared cache
provides them.

Use `extract_artifact` when materialized files from a supported format are needed.
It extracts the active target and accepts optional `integrity_policy`; see the [MCP contracts](https://github.com/morluto/rea/blob/main/docs/reference/mcp-contracts.md).
It materializes all regular files into a fresh temporary directory chosen by
REA. Symlinks and encrypted entries are inventory facts, not extractable files.
The result reports the materialized directory; callers do not choose the
destination. No separate permission grant is needed.

For iNES and NES 2.0 cartridges, `open_binary` recognizes the byte signature
without an executable architecture. `inspect_artifact` retains header facts and
each PRG/CHR file unit's offset, length and SHA-256; its nested inventory's
`ines.reconstruction` verifies the actual ordered region bytes against the
whole-file digest. Extraction includes the original header, optional trainer,
NES 2.0 miscellaneous ROM bytes and uninterpreted trailing bytes. These file
units are not mapper/CPU bank maps; NES 2.0 RAM, timing and console values are
header declarations. UNIF, dirty legacy headers, malformed NES 2.0 declarations
and truncated payloads are explicitly refused. No emulator or 6502 analysis is
performed. See the
[iNES guide](https://github.com/morluto/rea/blob/main/docs/ines-containers.md).

Native DMG traversal automatically uses a read-only mount on supported macOS
hosts, with an owned temporary mount directory and cleanup. It needs no approval
flag. Unsupported hosts or mount failures remain explicit limitations; do not
claim child inventory when only root identity is available. DMG extraction is
unavailable through `extract_artifact`. To access DMG files on macOS, create a
read-only mount with your own tools, select files from that mount for analysis,
and detach the mount you created when finished. REA's inspection mount is
temporary, not a retained export of the image's contents.

For headerless DOS COM, explicitly open with `format: "dos-com"` (CLI
`--target-format dos-com`). Do not pass a loader or base. Inspect the load
image before trusting function analysis. A Ghidra ComLoader import records
`loader: "ComLoader"` and `load_address: "0000:0100"` (linear entry `0x100`,
file offset zero) plus a zero-filled PSP placeholder at `0000:0000`. An image
ComLoader rejects records `loader: "BinaryLoader"`, `load_address: "1000:0100"`
(linear `0x10100`), and `loader_fallback.reason`. Segment context is imposed for
analysis. PSP contents, stack, and device state remain unmodeled. See [DOS guide](https://github.com/morluto/rea/blob/main/docs/providers/ghidra-dos.md).

Use `inspect_byte_entropy` to triage high- and low-entropy ranges before extraction,
and `inspect_firmware_vector_table` (`rea inspect-firmware-vector-table PATH --architecture ARCH --base-address HEX`)
to decode ARM M-profile exception/IRQ tables for the raw-image variant names
(`armv6-m` through `armv8.1-m.main`)
or RISC-V `mtvec` jump slots, flag clear Thumb bit-0 anomalies and shared dummy
handlers, and optionally bind CMSIS-SVD `<interrupt>` names via `svd_xml`.
See [firmware vector tables](https://github.com/morluto/rea/blob/main/docs/guides/firmware/firmware-vector-tables.md).
For ESP32/ESP8266 flash dumps or carved `partitions/nvs.bin` files (`esp-nvs`), use
`inspect_esp_nvs` (`rea inspect-esp-nvs PATH [--partition-offset N] [--partition-bytes N]`)
to decode ESP-IDF v1/v2 Non-Volatile Storage pages, CRC32 checksums, namespaces,
strings, integers, floats, and multi-chunk v2 blobs, marking older copies of a
key `superseded`; encrypted NVS entries are not decrypted. See [ESP-IDF NVS partitions](https://github.com/morluto/rea/blob/main/docs/guides/firmware/esp-nvs.md).

For other headerless images (embedded firmware without ELF/Mach-O/PE/MZ
headers), open with `format: "raw-binary"`, `architecture` (`x86`, `x86_64`,
`arm`, `arm64`, `6502`, or `m68k`), and `entry_point` (`0x` hex). File offset 0 is mapped at
that address. Hopper and IDA refuse this interpretation; Ghidra uses
`BinaryLoader` with a generic language: big-endian for `m68k`, little-endian
otherwise. For a Cortex-M dump, add `architecture_variant` (`armv6-m`,
`armv7-m`, `armv7e-m`, `armv8-m.base`, `armv8-m.main` or `armv8.1-m.main`)
and `base_address`, which maps file offset 0 separately; each requires the
other. Omit `entry_point` to take Reset from the vector table, adding
`vector_table_address` when a header precedes it. An odd entry is refused.
Results report canonical addresses (`0x08000000` as `0x8000000`) and treat an
omitted `vector_table_address` as one at the base; when your exact spelling
matters, save your request beside the Evidence, together with its
`evidence_id`. Big-endian ARM is unsupported.
`6502` selects NMOS 6502; the entry and complete file mapping must fit within
`0x0000..0xffff`. 65C02, 65816, cartridge containers, bank switching, and mapper
semantics are unsupported. `m68k` requires an even entry and decodes the 68040
superset of the 68000 family; Amiga/Atari containers and vector-table entry
discovery are unsupported. A Mega Drive or Genesis ROM is a container:
`inspect_artifact` reads its header, and an `.smd` dump is de-interleaved to
`program.bin`. Open that file as raw-binary `m68k` with `entry_point` set to
`rom.bus_start`, the 24-bit ROM start, usually `0x0`. Windows Ghidra P0 admits raw images only for `6502`. See [raw binary guide](https://github.com/morluto/rea/blob/main/docs/providers/raw-binary.md).

Intel HEX, S-record, UF2 and DfuSe files are containers, not raw images:
`inspect_artifact` lists address regions (UF2 per familyID, DfuSe per element
with its alternate setting), and `extract_artifact` writes each region. Open an
extracted region as `raw-binary` with its start address as `entry_point`. UF2
numbering gaps leave coverage unknown; a DfuSe suffix CRC mismatch follows
`integrity_policy`. See [UF2 and DfuSe](https://github.com/morluto/rea/blob/main/docs/uf2-dfuse.md).

### Function annotations in Ghidra

Fresh-import sessions admit annotations; existing-project reuse is read-only.
Use `annotate_native_function` for one function name, C prototype (`signature`) and/or entry comments, with at least one explicit change. When pseudocode for a target without debug information reads fixed offsets from one pointer, assert the layout with `define_native_data_types` and set the prototype; treat the resulting field names as your hypothesis (`signature_source: user_defined`, type `source: caller-defined`), not as recovered facts, and confirm each offset against the instructions. Review its annotation readback and refreshed dossier inline. Changes are atomic; empty comments clear them, omitted fields preserve them. Later MCP calls observe edits. Normal close saves them when owned Program checkpoint mode is enabled; ephemeral mode discards them. CLI `annotate-native-function` follows the same setting when closing after its updated result. Select the [checkpoint workflow](#continue-editable-ghidra-analysis-across-processes) before edits that must survive a later process. Original executable bytes are unchanged; edits invalidate immutable snapshots. Windows P0 does not admit database mutations. For naming only, `set_address_name` / `set_addresses_names` also work with Ghidra: they name function entries or data addresses (primary labels) and return compact per-address success booleans instead of a dossier. Ghidra rejects batch addresses that request the same name or a name another selected address holds; `raw_result.failures` gives each failure's reason.

A provider switch or different target can retire the active Ghidra database and discard
its edits, even if the new provider fails on a later call. Same-target,
same-profile reopen keeps the active database. Retained annotation Evidence
records what happened; it does not restore the edits.

For `compare_functions`, obtain `analyze_function` Evidence before and after the
edit while the MCP session is open; annotation Evidence is not a comparison
input. Export the needed Evidence before close if comparison will happen later.
Authenticated same-artifact coordinates preserve renamed entries as
`matched / same-entry`, with the canonical `entry_address` inline; name and
exact-text changes remain separate dimensions. This requires compatible
architecture, provider-owned mapping and selected-image commitments. Equal
numeric addresses alone cannot establish correspondence; inspect retained
source Evidence and coverage when the match remains ambiguous.

## Offline PE resource inventory

Use `inspect_pe_resources` with an absolute `path`, or
`rea inspect-pe-resources ./selected.exe --json`, for portable PE32/PE32+
resource inspection without opening a native target. Preserve returned Evidence:
type/name/language IDs and UTF-16 names, original directory/data/payload ranges,
code pages, payload hashes and static icon-group references. Same-language icon
resolution is explicit; missing references and size mismatch remain visible.
Other payloads are opaque, and this operation does not decode images or simulate
Windows resource loading. Consult the budgets and supported tree profile in
[offline binary diagnostics](https://github.com/morluto/rea/blob/main/docs/guides/native/binary-diagnostics.md).

## Offline PE and ELF export tables

Use `inspect_native_exports` with an absolute `path`, or
`rea inspect-native-exports ./libexample.so --json`, to read a PE export
directory or ELF dynamic symbol table on any host without opening a native
target. Ordinal-only, forwarded and hidden-version exports stay distinct;
partial or unsupported coverage means the inventory is incomplete, not that
exports are absent. Use `inspect_macho` for Mach-O. See
[offline binary diagnostics](https://github.com/morluto/rea/blob/main/docs/guides/native/binary-diagnostics.md).

## Godot PCK

For a standalone PCK, `open_binary` then `inspect_artifact` with
`detail: "summary"` retains the complete static inventory. Use the returned
`parent_evidence_id` with `inspect_analysis_view` inventory occurrences filtered
by exact `logical_paths` or `occurrence_ids`, and join `artifact_id` to nodes
filtered by `artifact_ids`. Select only needed fields; identity links remain.
Prefer `inspect-artifact --detail summary --evidence_output PATH` for CLI tasks;
the same CLI discovers embedded packs via their EOF trailer without opening a
native analysis provider. Normal native opening remains unchanged.

Distinguish declared MD5 from observed SHA-256 and graph/page completeness from
`source_coverage`. Encrypted directories and sparse bundles have unknown entry
coverage; encrypted members have unknown content identity. An empty filtered
page cannot prove absence in unknown coverage. Retained views are historical,
not fresh filesystem checks. No decryption, Godot resource decoding, GDScript
decompilation or target execution is provided. See
[Godot PCK](https://github.com/morluto/rea/blob/main/docs/godot-pck.md).

UnityFS AssetBundle containers (`.bundle`, `.ab`, YooAsset packages and other
byte-identified files) list `CAB-*` SerializedFiles and `.resS` members with
header and node facts; none/LZ4/LZ4HC member blocks stream on demand. Bundles
declaring asset-bundle encryption keep header facts with unknown directory
coverage; LZMA member bytes retain named occurrences with unavailable hashes.
Virtual member offsets are not physical carrier locations. Format 6–8 readers
cache one decoded block and support retained filtered/paged views. No
decryption or SerializedFile object decoding is provided. See
[UnityFS](https://github.com/morluto/rea/blob/main/docs/unityfs.md).

WeChat mini-program packages (`.wxapkg` files with `0xBE`/`0xED` marks) list
members with declared names and absolute carrier offsets; member bytes are
stored verbatim. `V1MMWX` PC-client packages report `encrypted` directory
status with unknown coverage and are refused on extraction; no decryption is
attempted. See
[wxapkg](https://github.com/morluto/rea/blob/main/docs/wxapkg.md).

macOS flat installer packages (`.pkg` files beginning with `xar!`) use the
same inspection/extraction workflows on every host. Prefer a retained summary
for XAR header/TOC facts, Distribution `pkg-ref` and choices, PackageInfo
identity, Scripts `preinstall`/`postinstall` presence, and gzip cpio Payload
paths, including each component's Scripts/Payload until the expansion budget
is exhausted. XAR signatures are named and not verified. `pbzx` payloads keep
the stored member with an unsupported-compression refusal; Bom is presence
and size only; installer JavaScript is never executed. See
[macOS flat installer packages](https://github.com/morluto/rea/blob/main/docs/macos-pkg.md).

U-Boot legacy uImages use the same inspection/extraction workflows. Prefer a
retained summary and selected inventory views for header facts or component
IDs. Header addresses/CPU/OS are declarations; payloads remain as stored.
Multi-file components retain their aligned physical ranges; the full payload
is also materialized. Unknown name text retains its original 32 bytes. See
[U-Boot uImage](https://github.com/morluto/rea/blob/main/docs/uimage.md).

Android boot, init_boot, recovery, and vendor_boot images use the same
inspection and extraction workflows. `ANDROID!` versions 0-4 and `VNDRBOOT`
versions 3-4 expose header facts and stored component bytes. The header does
not record whether an `ANDROID!` image is boot, init_boot, or recovery.
Command lines and names are target-derived. gzip, lz4, and zstd payloads stay
stored. The v4 signature and any AVB footer are reported with sizes and are
not verified. Extract `dtb` and pass that file to `inspect_devicetree`. See
[Android boot images](https://github.com/morluto/rea/blob/main/docs/android-boot-image.md).

Android DTBO partition table images (`0xd7b7ab1e`, table versions `0` and `1`)
expose child `dtbo-<index>.dtbo` blobs with `id`, `rev`, version-1 compression
flags (`none`, `zlib`, `gzip`, `unknown`), `custom` words, and leading
`0xd00dfeed` FDT magic checks. Compressed entries remain stored with explicit
limitations; extract uncompressed `0xd00dfeed` entries and pass them to
`inspect_devicetree`. Entry count and entry-table bytes are bounded via
`artifact_limits.android_dtbo`. See
[Android DTBO partition images](https://github.com/morluto/rea/blob/main/docs/android-dtbo.md).

ISO 9660 disc images (`CD001` at sector 16, any filename, even `.hop`) use
the same inspection and extraction workflows on every host, without mounting.
Volume identifiers and dates are target-derived. One tree is walked: an
eligible Joliet tree when present, else the primary tree (`name_source`).
Files only in an unwalked tree are not listed, so coverage is `unknown`
whenever the image has another tree. Unsafe names become `entry-<index>`
with the stored identifier in `source_path`. Separated multi-extent and interleaved files are listed with
unavailable hashes, so extract other files by `occurrence_ids`. Rock Ridge,
UDF, and El Torito boot images are not decoded. See
[ISO 9660 disc images](https://github.com/morluto/rea/blob/main/docs/guides/firmware/iso9660-images.md).

uClinux bFLT flat executables (`bFLT` magic, any filename) use the same
inspection and extraction workflows. The header does not name a CPU, so the
root architecture stays unknown. Header facts are big-endian declarations;
relocations are listed, not applied. `text.bin` (header included), `data.bin`
and `relocations.bin` are extractable. gzip and gzdata bodies are inflated
under `artifact_limits.expanded_bytes`; revision 2 bodies are read as stored.
Open `text.bin` as a raw binary with a chosen architecture. See
[uClinux bFLT flat executables](https://github.com/morluto/rea/blob/main/docs/bflt-executables.md).

Nintendo DS ROMs (`nds`) are detected from the header (logo CRC `0xCF56`,
unit code, ARM9 offset, and a matching logo or header CRC), not the filename,
and use the same inspection and extraction workflows. `root_format_metadata`
holds the cartridge header facts; members are `arm9.bin`, `arm7.bin`,
`overlays/<cpu>/overlay_<id>.bin`, FNT-named `data/<path>` files, and
unnamed `fat/<id>.bin` files. A CRC mismatch, a partial table, or a range past
the file end leaves coverage `unknown`. Secure-area encryption, compressed
overlays, and NitroARC archives are not decoded. See
[Nintendo DS ROMs](https://github.com/morluto/rea/blob/main/docs/guides/firmware/nds-roms.md).

Sega Mega Drive and Genesis ROMs (plain `.bin`, `.md`, `.gen`, or an
interleaved `.smd` copier dump) use the same inspection and extraction
workflows. Recognition is `SEGA` at file offset `0x100`, or the SMD copier
mark `0xAA 0xBB` at bytes 8 and 9 with a block count whose de-interleaved
bytes carry `SEGA`. Root metadata holds the vector table, header strings,
declared and computed checksum, ROM and RAM ranges, external RAM and region
codes. Members are `vectors.bin`, `header.bin` and `program.bin`. An SMD
member has no file offset because its bytes are de-interleaved. A checksum
mismatch or a ROM range that disagrees with the file leaves coverage
`unknown`. 32X and Sega CD system strings are reported and not decoded.
Extract `program.bin` and open it as raw-binary `m68k` with `entry_point`
set to `rom.bus_start` (usually `0x0`), so file offset 0 maps at that
address. Raw m68k does not apply the console's 24-bit address aliases, so use
the bus values, not the stored `rom.start`. `reset_pc_bus` is where code
begins; raw-binary does not discover
vectors, and analysis at `entry_point` `0x0` starts on the vector table.
Windows Ghidra P0 does not admit `m68k`. The image ceiling is 8 MiB, and an
SMD dump is at most 512 blocks; this release has no runtime override. See
[Sega Mega Drive ROMs](https://github.com/morluto/rea/blob/main/docs/guides/firmware/mega-drive-roms.md).

Nintendo 64 ROMs (`n64-rom`) are detected from the first word in z64
(`80 37 12 40`), v64 (`37 80 40 12`) or n64 (`40 12 37 80`) order, plus a
plausible boot address, and use the same inspection and extraction workflows.
`root_format_metadata` holds the cartridge header, the IPL3/CIC variant and
the CRC pair when that variant is known. Members are `header.bin`, `ipl3.bin`
and `program.z64`. v64 and n64 dumps serve those members in big-endian order
through a decoder; `decoded` records that swap. A CRC mismatch, an unknown
CIC, a short checksum window or reserved header bytes leave coverage
`unknown`. Nothing is executed or patched. `program.z64` is the big-endian
image. `boot_address` is the address IPL3 jumps to, not the address of file
offset 0. The MIPS lane admits ELF, and `raw-binary` does not admit
big-endian MIPS, so REA does not open this image as MIPS. See
[Nintendo 64 ROMs](https://github.com/morluto/rea/blob/main/docs/guides/firmware/n64-roms.md).

Legacy Qualcomm MBN boot images (`sbl1.mbn`, `aboot.mbn`, `tz.mbn`) use the
same inspection and extraction workflows. The header has no magic; REA claims
it only when version 3, 5 or 6 sizes and pointers are self-consistent.
MBN headers are 40 bytes for v3 and v5, and 48 for v6. Inventory lists stored
code, signature, certificate-chain and v6 metadata regions;
ranges past the file end are limitations with `unknown` coverage. ELF images
with a Qualcomm hash segment inventory as `qualcomm-mbn` (hash table and per
program header hash offsets) but still resolve as ELF for native analysis.
Signatures and certificates are located, not verified; hashes are not
recomputed. See
[Qualcomm MBN images](https://github.com/morluto/rea/blob/main/docs/guides/firmware/qualcomm-mbn-images.md).

Image4 firmware containers (`IMG4`, `IM4P`, `IM4M`) use the same inspection
and extraction workflows. Recognition is the DER SEQUENCE magic, not the
filename. `payload` is the stored octet string. `manifest.der` and
`restore-info.der` are the embedded IM4M and IM4R sequences. Keybags are
reported as a count and key types; nothing is decrypted, and an encrypted
payload is refused on open. Signatures and certificates are sized and not
checked. LZFSE (`bvx2`, `bvx1`, `bvxn`, `bvx-`) and `complzss` payloads stay compressed. IM4R property names
such as `BNCN` are listed and their values stay redacted. See
[Image4 containers](https://github.com/morluto/rea/blob/main/docs/guides/apple/image4-containers.md).

Android A/B OTA `payload.bin` files (CrAU v2) use the same
inspection/extraction workflows. Prefer a retained summary for header,
partition table, dynamic groups and signature counts. Signatures are not
verified. Reconstruct REPLACE, ZERO and REPLACE_ZSTD images only; delta
operations stay inventoried with unavailable content. See
[Android OTA update payloads](https://github.com/morluto/rea/blob/main/docs/guides/firmware/android-ota-payload.md).

Standalone Android Verified Boot `vbmeta.img` files (`AVB0` at offset 0) use
the same inspection and extraction workflows. The root records the header,
rollback index, flags, release string, and each property, hashtree, hash,
kernel command-line, and chain-partition descriptor. Unknown tags are
retained. `public_key_sha256` is the auxiliary public key; a chain descriptor
reports the SHA-256 of its own key bytes. Extract `authentication_block`,
`public_key`, and `public_key_metadata` when those ranges are non-empty.
Signatures and digests are recorded and not verified. An `AVBf` footer is not
this image. See
[Android Verified Boot vbmeta images](https://github.com/morluto/rea/blob/main/docs/guides/firmware/android-vbmeta.md).

Android sparse images (`system.img`, `vendor.img`, `super.img` with magic
`0xED26FF3A`) expand to one `image.raw` child without `simg2img`. Header,
chunk counts and stored checksums are root facts; checksums are not verified
and DONT_CARE blocks are written as zeros. The expanded child is classified
again. See
[Android sparse images](https://github.com/morluto/rea/blob/main/docs/guides/firmware/android-sparse-image.md).

UBI images (`UBI#` at offset 0, from `ubinize` or a NAND dump) use the same
inspection/extraction workflows. Prefer a retained summary for eraseblock
layout, PEB counts and volume counts. Each volume is `volumes/<name>`,
reassembled from its LEBs by highest sqnum. A volume with a missing LEB
stays inventoried with unavailable content. UBIFS inside a volume is not
decoded. See
[UBI images](https://github.com/morluto/rea/blob/main/docs/guides/firmware/ubi-images.md).

Nintendo Switch NSO modules (`NSO0`) and NRO executables (`NRO0` at `0x10`)
use the same inspection and extraction workflows, without running or
disassembling them. Root metadata holds the `module_id` build id and MOD0
offset for matching crash logs. Entries are the text, rodata and data
segments, plus NRO `ASET` icon, NACP and RomFS. Compressed NSO segments are
LZ4-decoded within `artifact_limits.expanded_bytes` and their SHA-256 compared
with the header (`hash_status`). Truncated or over-budget segments stay listed
with unavailable content. See
[Switch executables](https://github.com/morluto/rea/blob/main/docs/guides/firmware/switch-executables.md).

## ESP images

For an ESP32-family app or bootloader image, `open_binary` then
`inspect_artifact` with `detail: "summary"`. `root_format_metadata` holds the
observed `header` and `descriptor` (its `kind` is the app or bootloader role)
and the derived `chip`, `checksum`, `appended_sha256` and
`undescribed_trailing` ranges. Segment rows (`segment-NN.bin`) carry
`load_addr`, `classification` (`mapped`, `loaded`, `not-loaded` or `unknown`,
per ESP-IDF `should_map`/`should_load`; RAM ranges are not checked) and
`source_location`; select them with `inspect_analysis_view` and
`logical_paths`. Signature blocks are `unverified`; `public_key_sha256`
matches eFuse key digests.

Unknown `source_coverage` means truncation or undescribed trailing bytes, such
as the flash segments of a `--ram-only-header` image; do not infer absence
from it. Erased flash is described. Integrity mismatches are facts, not
refusals. ESP8266 images are refused, and flash-encrypted images are not
recognized. Segments are not disassembled, and RISC-V or Xtensa segments
cannot be opened as raw-binary. See
[ESP images](https://github.com/morluto/rea/blob/main/docs/esp-image.md).

## ESP flash images

A whole-flash dump opens as `esp-flash-image`. `root_format_metadata` holds
`partition_table` (its `method`: `default`, `caller` or a derived
`scan`), `bootloader` and `apps` ESP image facts, the `otadata` records,
`partitions_outside_dump` and `boot_selection`. Every table has a
`boot_selection`: its `basis` names the bootloader's branch (`no-otadata`
without otadata, `none` when the bootloader rejects the table, `unknown`
when a record is missing), and it lists its `assumptions`;
`running_partition` is always `unknown`. Each image names its entry
`path`. With `detail: "summary"` the root kind is `esp-flash-image-summary`
and each image is a compact `summary` (chip, entry point, segment count,
classified load ranges, signature block count, descriptor identity,
integrity); complete detail keeps every segment. Partition rows
(`partitions/<label>.bin`) carry the declared `type`, `subtype`, names,
`flash_address`, `size` and flags; `encrypted` is a storage flag, not
proof of ciphertext. `written_offset`/`written_end` bound the bytes that
are not erased: an app slot whose facts say `erased` can still hold an older
image, and a limitation says so. For a dump read from another flash address, call
`open_binary` with `format: "esp-flash-image"` and `flash_offset`; an
`esp-image` whose `flash_dump` is set names that offset in a next probe; a
relocated table can be named with `partition_table_offset`. No table found
means unknown, often flash encryption. Extraction writes `nvs_keys` as
ordinary data. See
[ESP flash images](https://github.com/morluto/rea/blob/main/docs/esp-flash-image.md).

## Bun standalone executables

A `bun build --compile` executable stores its module graph in Mach-O
`__BUN,__bun`, a PE or ELF `.bun` section, or an appended trailer.
`open_binary` then `inspect_artifact` reports root format `bun-standalone` with
the carrier, structural layout, module count, entry point, raw flags and
compile exec-argv; each module keeps its `/$bunfs/...` source name, loader,
encoding, sizes and SHA-256, with sourcemap, bytecode and module-info regions as
separate children. Use summary root metadata `entry_point_logical_path` as the
exact inventory `logical_paths` selector, then read the selected content node by
its artifact ID; the reader owns virtual-name normalization and indexed fallback. `extract-artifact` writes stored contents through the safe
output tree; route extracted JavaScript to `analyze_javascript_application`.
Layout labels describe record shapes, not a detected compiler version; unknown
or ambiguous layouts are unsupported. Bytecode is retained, not decoded, and the
executable is never run. See
[Bun standalone executables](https://github.com/morluto/rea/blob/main/docs/bun-standalone.md).

## Deno compile executables

A `deno compile` executable stores its application in a Mach-O `__SUI,d3n0l4nd`
section, an Intel Mach-O `<~sui-data~>` trailer, an ELF `SUI` note of type
`0x53554901`, or a PE `RT_RCDATA` resource named `D3N0L4ND`.
`open_binary` then `inspect_artifact` reports root format `deno-standalone`
with the carrier, entry point, recorded options, and one occurrence per virtual
file, including size and SHA-256. Transpiled output, CJS export analysis, and
source maps are separate occurrences with the file's `index` and their own
`role`. They normally use a `.deno-*` suffix on the file path and move to an
indexed path on a collision, so use the reported `logical_path`. Symlink targets
stay recorded path parts. A virtual filesystem that cannot be listed leaves
coverage unknown.
Environment-file values and CA certificate bytes are retained in local Evidence
with their counts and byte lengths. The npm snapshot length is reported and not
decoded. `extract-artifact` writes
stored files through the safe output tree; route extracted JavaScript to
`analyze_javascript_application`. Other layouts are unsupported, and the
executable is never run. See
[Deno compile executables](https://github.com/morluto/rea/blob/main/docs/deno-standalone.md).
