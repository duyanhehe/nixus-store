# Nguồn của agent `agency-marketing-social-media-strategist`

Một agent lẻ của gói `nixus.agency-agents`, lấy từ [msitarzewski/agency-agents/marketing/marketing-social-media-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/marketing/marketing-social-media-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Nixus (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Nixus báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
