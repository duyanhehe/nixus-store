# Nguồn của agent `agency-roblox-experience-designer`

Một agent lẻ của gói `nixus.agency-agents`, lấy từ [msitarzewski/agency-agents/game-development/roblox-studio/roblox-experience-designer.md](https://github.com/msitarzewski/agency-agents/blob/main/game-development/roblox-studio/roblox-experience-designer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Nixus (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Nixus báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
