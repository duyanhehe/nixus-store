# Signal Plays

A list tells you who could buy. A signal tells you who might buy now. This reference turns signals into outbound plays: which signals to trust, how fresh they need to be, what to do when one fires, and how much effort each account deserves.

Signals are a timing and relevance filter. They don't replace ICP fit. A strong signal at a company outside your ICP is still a skip, and a great-fit account with no signal can still get a well-aimed message built on its situation.

## Rank signals by how close they are to you

The closer the signal is to your product and your past customers, the better it converts. Work down this list and stop where you have enough volume:

| Rank | Signal | Why it works | Typical source |
|------|--------|--------------|----------------|
| 1 | **Your own product usage**: a signup from a company domain, a plan limit hit, a big upload, a team invite | They already chose you once | Your product analytics, billing |
| 2 | **Past champions changing jobs** | Former users bring the tool with them; vendors report win rates roughly double when the buyer has used the product before | CRM contacts + job-change tracking (UserGems, Clay, manual LinkedIn checks) |
| 3 | **High-intent website visits**: pricing, comparison, integration pages | Active evaluation | Visitor identification (RB2B, Warmly, Vector), your analytics |
| 4 | **Engagement with you or a competitor**: comments on your posts or a competitor's, community questions | Public interest in the problem | Trigify, Common Room, social listening |
| 5 | **Hiring in the function you serve**, or a new leader in it | New budget and a mandate to change things | Job boards (TheirStack, PredictLeads), LinkedIn |
| 6 | **Funding, launches, expansion** | Budget, plus pressure to grow fast | Crunchbase, news, press releases |
| 7 | **Tech stack changes**: adding or dropping a tool next to yours | A related decision is in motion | BuiltWith, Wappalyzer, job-post tech mentions, subprocessor lists |
| 8 | **Generic third-party intent** | Weakest, and noisy | Bombora-style intent feeds, review-site intent |

Stack signals before acting on the weaker ones. Hiring a lifecycle marketer **plus** an ESP in the stack **plus** a fit score above your threshold is worth a sequence. Any one of those alone usually isn't.

## Warm paths: your network is a signal too

Before buying a list, mine the relationships you already have. A warm introduction gets read when the twentieth cold email of the day doesn't, and AI-written outreach makes that gap wider.

1. **Export your network.** LinkedIn connections (Settings → Data privacy → Get a copy of your data), calendar attendees, and inbox contacts. LinkedIn's export includes emails only for connections who allow it.
2. **Enrich and rank** every contact: company, role, industry, headcount. Score them against your ICP like any other list.
3. **Match against target accounts** to find first- and second-degree paths into the companies you want.
4. **Start with your calendar.** Recent meetings show who is in a buying moment right now.
5. **Find one connector per vertical**: someone trusted by buyers who ignore cold outreach (an agency owner who knows every other agency owner). Pay them the way you'd pay for a qualified meeting, and disclose the arrangement.
6. **Double opt-in intros only.** Ask the connector, then the target, before anyone is introduced. Keep a human approving every intro, and never ask one contact to take intros for two vendors in the same week. Trust is the asset; spend it slowly.

*Adapted from Cody Schneider's podcast with Chris of Super Connector (October 2026).*

## Freshness windows

A signal decays. Act inside these windows or downgrade it:

| Signal | Act within | After that |
|--------|-----------|------------|
| Product usage spike, limit hit | Same day (ideally within minutes) | Treat as a normal product-qualified lead |
| Pricing or comparison page visit | 24 hours | Drop to the general list |
| Champion job change | 30–90 days in the new role | They've already chosen their stack |
| New leader in the function | First 90 days | Priorities are set |
| Job post for the function | While the post is open, up to ~60 days | Hire made, budget allocated |
| Funding announcement | 30–60 days | Old news; don't congratulate on it |
| Tech install or removal | 30 days | Decision done |
| Priority stated on a podcast or in a talk | 90 days from the air date | Background on the person, not a trigger |

Record the signal date on every lead. A lead sheet without signal dates can't be prioritized.

## From signal to play

Every signal you track should map to a specific play, so nobody improvises the angle at send time:

| Signal | Play | Opening angle | Channel order |
|--------|------|---------------|---------------|
| Product limit hit | Sales-assist | Offer to help them get more from the plan they're outgrowing | Email from a founder or account owner within minutes, then LinkedIn |
| Champion job change | Reunion | Reference the work they did with you before; ask how the new team handles it | LinkedIn first (they're updating their profile), then email |
| Pricing page visit (identified) | Evaluation help | Don't mention the visit. Lead with the decision they're probably weighing | Email, then call for Tier 1 |
| New leader in the function | First 90 days | The thing new leaders in that role usually fix first, with proof | LinkedIn connect, then email |
| Hiring for the function | Bridge the gap | What they can get done before the hire lands, or what the hire will need | Email |
| Competitor engager | Alternative | The problem they engaged with, not the competitor | LinkedIn, then email |

Write the angle as the problem the signal implies. "Saw you raised a Series A" is a fact everyone else sent. "Most teams that just raised are told to double pipeline in two quarters, and the site usually becomes the bottleneck" is a reason to reply.

## Gap plays: a signal plus a gap you can see

The strongest services and tooling plays pair two things: a signal that the company is spending or growing, and a gap you can verify from outside that your offer fixes. The signal says they have budget and a reason to act. The gap gives you a specific, checkable opener instead of a guess.

| Signal | Gap to verify | How to check it from outside | Fits an offer like |
|--------|---------------|------------------------------|--------------------|
| Recent funding or a new marketing leader | The site hasn't changed in a long time, or doesn't match the new story | Wayback Machine snapshots, the copyright year, positioning that doesn't match the funding announcement | Website, CRO, positioning |
| Hiring several SDRs or BDRs | The outbound stack doesn't match the plan | The tools named in the job post, sending-domain DNS (SPF, DKIM, DMARC), the tech stack | Email infrastructure, enrichment, deliverability |
| Hiring for repetitive work (data entry, reporting, lead research, CRM admin) | The job post describes tasks that can be automated | The responsibilities list in the post itself | Automation, RevOps, AI agents |
| Running paid ads | No visible ad or analytics tags | Page source, browser network tab, or a tag-checker extension (Meta Pixel Helper, Google Tag Assistant) | Tracking and attribution setup |
| Running paid ads | Paid traffic lands on the homepage | The destination link on each ad in the Meta Ad Library or LinkedIn Ad Library | Landing pages, CRO |
| Running the same ads for months | Creative fatigue | Start dates in the Meta Ad Library; the Google Ads Transparency Center for search and YouTube | Ad creative |
| Many locations | Missing or thin location pages | Store locator count vs. pages found with `site:domain.com/locations`; Google Business Profiles per location | Local SEO |
| Many integrations or use cases | Few pages about them | The integrations directory vs. a `site:` search for integration or use-case pages | Programmatic SEO, content |
| A lead magnet (ebook, calculator, webinar) | No follow-up after opt-in | Opt in with an address you control and log every email for 14 days, then unsubscribe | Email nurture, lifecycle |
| Expanding into a new country | The site isn't localized for it | Language switcher, `hreflang` tags, local currency and payment methods on pricing | Localization, international SEO |

**Rules for gap plays:**

1. **Verify the gap; never assume it.** Record what you checked, the date, and a screenshot or URL. An agent asked to find gaps will invent them unless every gap needs evidence. "No gap found" is a valid result, the same as "no hook found" in [account-research.md](account-research.md).
2. **Know what can't be seen from outside.** Server-side tracking (Meta's Conversions API, server-side Google Tag Manager) doesn't show in page source, so a missing browser tag isn't proof of missing tracking. Ask, don't accuse. A homepage is also a normal destination for brand-name search ads, and an ad running for months may be the winner rather than tired. Ad longevity is a proxy, not proof.
3. **Re-check before sending.** Gaps get fixed. Re-verify within 7 days of the first touch, or drop the gap from the message.
4. **The gap must map to your offer.** Spotting a problem you can't fix is research, not a play.
5. **Lead with the observation and a question, not a verdict.** "Your Meta ads for the spring launch point to the homepage. Is that on purpose?" gets replies. "Your landing pages are wasting your ad spend" gets deleted. Offer the evidence, and the teardown, only after they say yes (see the cold-email skill's outbound plays reference).

Searching for these by hand is slow, which is why the plays used to be rare. Agents with web, ad-library, and X search access (Grok, for example, searches X directly) can build the list. A human still reviews the evidence for Tier 1 and a sample for Tier 2. Once a play gets replies, run it on a schedule with the signal-sweep loop in the marketing-loops skill.

## Subprocessor lists: a stack the company publishes itself

A company that handles customer data has to tell its customers which other vendors process that data. Most publish the list on a subprocessors page, linked from the DPA (data processing agreement), the privacy policy, or a trust center. It is a first-party record of part of the stack, with each vendor's name, what it is used for, and often where the data sits. No tag-sniffing or guessing from job posts is involved.

**Three ways to use it:**

| Use | How |
|-----|-----|
| **Find accounts by a tool they use** | Search for pages that name the vendor as a subprocessor: `"subprocessors" "<vendor>"` or `intitle:subprocessors "<vendor>"`. Every hit is a company that says, in a legal document, that it uses that vendor |
| **Qualify an account you already have** | Open its subprocessors page before writing. It shows whether a tool in your category is already in place, and which neighbouring tools yours would have to work with |
| **Catch a change** | A vendor added or dropped is a dated tech-stack signal. Many pages show a "last updated" date or let anyone subscribe to change notices by email, which turns the page into an alert. Compare against a saved copy or a web archive snapshot when there is no date |

**Where to look:** `/subprocessors`, `/legal/subprocessors`, `/dpa`, `/trust`, a `trust.` subdomain, or the privacy policy's section on third parties. Larger companies list them per product.

**Rules for subprocessor lists:**

1. **It is a partial stack.** The list covers vendors that process the company's *customers'* personal data: hosting, email delivery, support desks, product analytics, AI model providers, payments. Tools the company uses on its own behalf, such as its CRM or ad platforms, are usually absent. It suits offers that sit in or next to the product, and is weak evidence for sales and marketing tools.
2. **Absence proves nothing.** A vendor missing from the list may be used in a way that touches no customer data, or the page may be out of date.
3. **Names are legal entities.** The list may show a parent or a registered company name where you expect a product name. Search for both before concluding a tool isn't there.
4. **Record the page URL and the date you read it**, the same as for gap plays, and re-check before the first touch.
5. **Open with the problem the stack implies, not the lookup.** "I saw you on a subprocessor list" reads as surveillance, the same as mentioning a tracked visit. Use what the stack tells you to choose the angle.

## Podcast appearances: the problem in the prospect's own words

Founders and functional leaders go on podcasts and say what they are working on, what broke, and what they plan to fix. Episodes are now indexed with speaker-labelled transcripts, so a search returns the quote, the timestamp, the show, and who said it. That is a dated, public statement of a priority, in the buyer's own language.

| Use | How |
|-----|-----|
| **Find people describing the problem you solve** | Search episode transcripts for the problem in plain words, not your category name. Each hit is a named guest, a company, and a quote |
| **Research an account before writing** | Search for the leader's name or company. What they said they are focused on this quarter beats a guess from their job title |
| **Find the shows your buyers appear on** | The shows that keep booking your ICP are where to pitch a guest spot (hand off to **public-relations**) |

**Rules for podcast signals:**

1. **Check the air date.** A priority stated on a podcast holds for about a quarter. Past 90 days, treat it as background, not a trigger.
2. **Confirm who said it.** Speaker labels in transcripts are sometimes wrong, and hosts paraphrase guests. Open the episode page and check the guest, the company, and that the quote is theirs.
3. **A guest is not a buyer yet.** Apply ICP fit like any other lead. A good quote from a company outside the ICP is still a skip.
4. **You can name the episode.** Unlike a tracked visit or a lookup, a podcast is something they chose to publish. "Heard you on [show] talking about [their point]" is welcome when the point is real and specific. Quote it accurately and don't stretch it.
5. **One reference, then your own point.** The episode earns the open. The rest of the message is about their problem and what you'd do about it.

*Lead source suggested by Firecrawl's podcast index.*

## Org-shape signals: what the team's structure tells you

Funding and job posts are events, and every vendor sees them. These signals come from the shape of the team: who is there, who just left, and what doesn't match other companies of the same size. Fewer senders act on them.

| Signal | What it suggests | How to detect it from public data | Act within |
|--------|------------------|-----------------------------------|------------|
| **A leader in the buying function left**, with no replacement announced | Decisions wait, then a new owner reviews every tool | Their profile shows a new employer; the company's team or leadership page no longer lists them | From the departure until a replacement starts, then switch to the first-90-days play |
| **A role companies of this size usually have, and nobody holds** | The work is undone, or split across people who own something else | A people search for the title and its variants returns no one; the team page shows no owner; no open post for it | While it's true. Re-check before every touch |
| **A team's headcount is growing with no open job posts** | Hiring through referrals or agencies; the team is scaling quietly | The function's headcount on two dates you recorded, against the careers page | 60 days from the growth you measured |
| **A switch of a system of record** (applicant tracking, CRM, help desk) | A team is changing how it works, with budget and attention on process | The domain behind the careers page's apply links changes vendor; tech-stack lookups; the vendor's customer page | 30 days, like any tech change |
| **An unusual title in the buying function** | The company organises the work differently from your ICP assumption | Titles on profiles and the team page, compared with the usual titles in your segment | No window. It changes who you write to, not when |

**Rules for org-shape signals:**

1. **Absence is weak evidence.** "Nobody holds the role" can mean a different title, a contractor, or an agency doing the work. Treat a missing role as a guess until a second signal backs it (adjacent hiring, funding, a gap you verified), and ask who owns the work instead of stating that no one does.
2. **Record what you checked and when**: the search, the page, and the date, the same as for gap plays.
3. **Never write about the person who left.** Don't name them, guess why they went, or ask them about their former employer. Write to whoever is covering the function about the situation the team is in.
4. **Growth needs two dated measurements.** One headcount number isn't a trend, and profile-based headcounts lag and are self-reported.
5. **Get profile data by hand or from a licensed provider**, as everywhere else in this skill. Don't scrape it.

| Signal | Opening angle | Write to |
|--------|---------------|----------|
| Leader left | What teams usually keep running during the gap, and what is cheap to fix before the new leader arrives | The person covering the function: their manager, or the most senior person left on the team |
| Missing role | Ask who owns the work today, then offer what gets it done without the hire | The executive the role would report to |
| Quiet growth | The thing that breaks when a team that size doubles, with proof | The team's leader |
| System switch | What teams usually revisit in the same quarter as that migration | The owner of the system being replaced |
| Unusual title | Their own name for the function, and the problem as that role would describe it | The person holding the title |

*Signals adapted from Julien Lieben's GTM playbooks (ColdIQ, November 2026).*

## Two worked examples

**A services agency selling to B2B SaaS (for example, a CRO and landing page agency)**
- **Signals:** funding in the last 60 days; a new VP Marketing or head of growth; open roles for growth or performance marketers; a redesigned site or new pricing page; paid search or paid social campaigns launching.
- **Play:** value first, built on a verified gap from the gap plays table. Offer a short teardown of their actual page. Send it only after they say yes. See the cold-email skill's outbound plays reference.
- **Volume:** about 50 well-researched accounts a week beats 5,000 generic sends. Agencies rely on depth.

**A self-serve SaaS tool (for example, an email verification product)**
- **Signals:** signups from company domains; credit or plan limits hit; large list uploads; team invites. Off-product signals include companies hiring lifecycle, RevOps, or SDR roles and cold-email tools appearing in their stack.
- **Play:** product-led outbound for usage signals, problem-led cold outbound for the rest. The outbound plays reference covers both.
- **Volume:** usage signals are few but hot. Cold lists can be larger, but every send has to model the deliverability the product sells.

## Account tiers

Tiers decide how much research and how many channels each account gets. Assign the tier before writing anything.

| Tier | Accounts | Research | Channels | Copy |
|------|----------|----------|----------|------|
| **Tier 1 (1:1)** | Top ~25–50 by fit and signal | A full account brief (see [account-research.md](account-research.md)), mobile numbers | Email, LinkedIn, phone, video, possibly direct mail | Written per person; a human reviews every message |
| **Tier 2 (1:few)** | Segments of 20–200 sharing one specific pain | Segment research plus one personal line | Email + LinkedIn | Written per segment, with a personal opener; a human reviews a sample |
| **Tier 3 (1:many)** | Everyone else who fits | The segment definition is the research | Email | Written per segment; relevance comes from how tightly the segment is defined |

Keep campaigns small. Several vendor and agency datasets show reply rates falling as campaign size grows, with campaigns of 50 or fewer recipients replying at roughly twice the rate of campaigns over 1,000.

## Tools for detecting signals

Each tool is listed with what it is and when to reach for it. Name the ones that fit the user's signals, more than one where several do.

| Tool | What it is | Reach for it when |
|------|------------|-------------------|
| [TheirStack](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/theirstack.md) | Job-posting and tech-stack database, with an MCP server | Finding companies hiring for the function you serve |
| [PredictLeads](https://predictleads.com) | Company-event data API: job openings, news events, technology detections | You want hiring, news, and tech changes from one feed |
| LinkedIn Jobs | Public job posts, checked by hand | A short account list and no budget |
| [UserGems](https://www.usergems.com) | Job-change tracking for past customers and champions | Past users move often enough to run a reunion play |
| [Clay](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/clay.md) | Enrichment workspace with job-change tracking, and an MCP server | The list is already enriched in Clay |
| [RB2B](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/rb2b.md) | Website visitor identification at the person level, US only | You want to know which people viewed pricing or comparison pages |
| [Warmly](https://www.warmly.ai), [Vector](https://www.vector.co) | Website visitor identification | The same need; compare coverage for your traffic |
| [Trigify](https://www.trigify.io) | Tracking of who engages with chosen social posts and profiles | The play starts from engagement with you or a competitor |
| [Common Room](https://www.commonroom.io) | Signal aggregation across community, social, and product data | Signals arrive from several places and need one account view |
| [Crunchbase](https://www.crunchbase.com) | Company and funding database | Funding rounds and launches are the trigger |
| [Exa](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/exa.md) | Search API that finds pages by meaning, with an MCP server | Finding news, announcements, and posts about target accounts |
| Podcast transcripts | Indexed episodes with speaker-labelled transcripts, searchable by topic or person, for example through [Firecrawl](https://github.com/coreyhaines31/marketingskills/blob/main/tools/integrations/firecrawl.md)'s Alexandria library; show notes and episode pages by hand | Someone at a target account described the problem, or you need what a leader said they are working on |
| X search | Public posts and announcements; Grok searches X directly through the xAI API | The signal is something a founder or team said in public |
| Meta Ad Library, Google Ads Transparency Center, LinkedIn Ad Library | Public archives of running ads | Checking whether and how a company advertises, by hand in the browser |
| [BuiltWith](https://builtwith.com), [Wappalyzer](https://www.wappalyzer.com) | Lookups of the technology a website runs | A tool next to yours being added or dropped is the trigger |
| Subprocessor and DPA pages | A company's own published list of the vendors that process its customers' data | Confirming an account uses a named vendor, or catching one being added or dropped. Free, by search |
| Your own analytics and billing events | Product usage, sent to the CRM by webhook | The signal is a signup, a limit hit, or a team invite |

Setup guides for TheirStack, Clay, RB2B, and Exa are in the [tools registry](https://github.com/coreyhaines31/marketingskills/blob/main/tools/REGISTRY.md). For the others, use the vendor's own docs, and check what each one offers an agent before planning around it. A scheduled sweep of these sources is the signal-sweep loop in the marketing-loops skill.

## Common mistakes

- Treating any funding round as a buying signal for everything.
- Opening with the signal itself ("Congrats on the raise"). Use it to choose the angle, then talk about their problem.
- Acting on stale signals. A six-month-old job change is just a job.
- Mentioning website visits that the prospect doesn't know were tracked. It reads as surveillance.
- Running every account at the same depth. Tier first.
